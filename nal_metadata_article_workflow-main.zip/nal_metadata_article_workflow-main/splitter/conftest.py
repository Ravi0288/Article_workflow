import pytest

# Define data paths in a dictionary
data_paths = {
    "crossref_api_response": "data/crossref_api_response.json",
    "submission_api_collection": "data/submit_site_api_collection.json",
    "amchsoc_jats": "data/American_Chemical_Society_jats.xml",
    "cambridge_jats": "data/Cambridge_jats.xml",
    "elsvier_consyn": "data/Elsevier_consyn.xml",
    "pagepress_jats": "data/PAGEPress_jats.xml",
    "springer_pubmed": "data/Springer_pubmed.xml",
    "taylor_jats": "data/Taylor_jats.xml",
    "wiley_pubmed": "data/Wiley_pubmed.xml",
}


def load_data(data_name):
    """Loads data from a file based on the provided name."""
    with open(data_paths[data_name], "r") as file:
        return file.read()


@pytest.fixture(scope="session")
def crossref_api_response():
    return load_data("crossref_api_response")


@pytest.fixture(scope="session")
def submission_api_collection():
    return load_data("submission_api_collection")


@pytest.fixture(scope="session")
def amchsoc_jats():
    return load_data("amchsoc_jats")


@pytest.fixture(scope="session")
def cambridge_jats():
    return load_data("cambridge_jats")


@pytest.fixture(scope="session")
def elsvier_consyn():
    return load_data("elsvier_consyn")


@pytest.fixture(scope="session")
def pagepress_jats():
    return load_data("pagepress_jats")


@pytest.fixture(scope="session")
def springer_pubmed():
    return load_data("springer_pubmed")


@pytest.fixture(scope="session")
def taylor_jats():
    return load_data("taylor_jats")


@pytest.fixture(scope="session")
def wiley_pubmed():
    return load_data("wiley_pubmed")


@pytest.fixture(scope="session")
def simple_text():
    return "Simple text"


@pytest.fixture(scope="session")
def broken_xml():
    text = '''<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE ArticleSet PUBLIC "-//NLM//DTD PubMed 2.8//EN" "https://dtd.nlm.nih.gov/ncbi/pubmed/in/PubMed.dtd">
<ArticleSet>
   <Article>
      <Journal>Journal of camping</Journal>
'''
    return text


@pytest.fixture(scope="session")
def broken_json():
    text = '''
[
  {"id":1}

'''
    return text


@pytest.fixture(scope="session")
def unknown_json():
    text = '''
[
  {"id":1}
]
'''
    return text
