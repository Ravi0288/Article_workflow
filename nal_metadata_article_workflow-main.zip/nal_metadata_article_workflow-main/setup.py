from setuptools import setup

setup(
    name='nal_metadata_article_workflow',
    version='0.1',
    packages=['splitter', 'splitter.src'],
    url='',
    license='Government Purpose Rights',
    author='Chuck Schoppet',
    author_email='chuck.schoppet@usda.gov',
    description='Metadata libraries for NAL article citation workflow'
)
