## Splitter

This module supports the splitting of metadata collection documents into single record documents preserving the 
metadata original schema or DTD.

### Supported formats and schemas

| Source          | format | schemas    | Notes                                                                |
|-----------------|--------|------------|----------------------------------------------------------------------|
| CrossRef API    | JSON   | Crossref   | [CrossRef JSON](https://github.com/CrossRef/rest-api-doc/blob/master/api_format.md) |
| Submit site API | JSON   | custom     | [Submit site API](https://github.com/USDA-REE-ARS/nal-library-systems-support/wiki/Submission-Export-API) |
| JATS            | XML    | JATS 3.0   | [Tags](https://dtd.nlm.nih.gov/archiving/tag-library/3.0/index.html) |
| PubMed          | XML    | PubMed 2.8 | [PubMed XML](https://www.ncbi.nlm.nih.gov/books/NBK3828/#publisherhelp.PubMed_XML_Tagged_Format) |
| Elsevier ConSyn | XML    | Elesvier   | [ConSyn Schemas](https://supportcontent.elsevier.com/Support%20Hub/DaaS/36178_ConSyn_Schemas_Document.pdf) |
