# nal_metadata_article_workflow
This Python library that supports the metadata work in the Django article workflow found at
https://github.com/USDA-REE-ARS/nal_django_article_workflow

## Splitter

This module supports the splitting of metadata collection documents into single record documents preserving the 
metadata original schema or DTD.

      
