from django.apps import AppConfig


class Step5Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'step5'
