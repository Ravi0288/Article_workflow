#from metadata_routines.splitter.splitter import splitter as splitter
#from metadata_routines.mapper.mapper import mapper as mapper
print("Ran metadata init")
